# config.py for cloudSQL

DATABASE_CONFIG = {
        'host': '10.241.16.3',
        'user': 'ahmad-gcp',
        'password': 'GCP-database1',
        'database': 'app-sql_prod'
}